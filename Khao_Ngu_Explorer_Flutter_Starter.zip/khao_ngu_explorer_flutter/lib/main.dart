
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

void main() => runApp(const KhaoNguApp());

const forest = Color(0xFF287A3C);
const leaf = Color(0xFF8DBF72);
const pale = Color(0xFFF5F7E9);
const cream = Color(0xFFFFFDF4);
const ink = Color(0xFF24352A);
const gold = Color(0xFFFFC94A);

class KhaoNguApp extends StatelessWidget {
  const KhaoNguApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Khao Ngu Explorer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: forest, surface: cream),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: pale, foregroundColor: ink, centerTitle: true,
          elevation: 0, titleTextStyle: TextStyle(
            color: ink, fontSize: 18, fontWeight: FontWeight.w800),
        ),
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int tab = 0;
  int eggProgress = 1;
  int score = 0;
  final Set<int> unlocked = {0};

  void addEggProgress() => setState(() {
    if (eggProgress < 5) eggProgress++;
    if (eggProgress == 5) unlocked.add(1);
  });

  void addScore() => setState(() => score += 10);

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onExplore: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const ExplorePage())),
        onGame: () => setState(() => tab = 2)),
      const Map360Page(),
      EggGamePage(progress: eggProgress, onTapEgg: addEggProgress),
      CollectionPage(unlocked: unlocked),
      ProfilePage(score: score, progress: eggProgress),
    ];
    return Scaffold(
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        backgroundColor: cream,
        indicatorColor: const Color(0xFFE3F0D7),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'หน้าหลัก'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'แผนที่'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'เกม'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'สะสม'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'โปรไฟล์'),
        ],
      ),
    );
  }
}

class Mascot extends StatelessWidget {
  final double size;
  const Mascot({super.key, this.size = 74});
  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      color: const Color(0xFFE6F2D8),
      borderRadius: BorderRadius.circular(size / 2),
      border: Border.all(color: const Color(0xFFC6DDAE), width: 2),
    ),
    child: Center(child: Text('🐍', style: TextStyle(fontSize: size * .57))),
  );
}

class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: cream, borderRadius: BorderRadius.circular(22),
      border: Border.all(color: const Color(0xFFE8EBD9)),
      boxShadow: const [BoxShadow(color: Color(0x11000000), blurRadius: 12, offset: Offset(0, 4))],
    ),
    child: child,
  );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? trailing;
  const SectionTitle(this.title, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: ink))),
      if (trailing != null) Text(trailing!, style: const TextStyle(color: forest, fontWeight: FontWeight.w700)),
    ],
  );
}

class HomePage extends StatelessWidget {
  final VoidCallback onExplore;
  final VoidCallback onGame;
  const HomePage({super.key, required this.onExplore, required this.onGame});

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(padding: const EdgeInsets.all(18), children: [
      Row(children: [
        const Expanded(child: Text('Khao Ngu Explorer', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: forest))),
        const CircleAvatar(backgroundColor: Color(0xFFE6F2D8), child: Text('🌿')),
      ]),
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(colors: [Color(0xFFDDEFCB), Color(0xFFFDF5D7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('ออกสำรวจโลกเขางู', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: ink)),
              SizedBox(height: 6),
              Text('เรียนรู้ธรรมชาติ ประวัติศาสตร์ และเรื่องราวรอบตัว', style: TextStyle(color: ink, height: 1.4)),
            ])),
            const Mascot(size: 88),
          ]),
          const SizedBox(height: 16),
          const LandscapePlaceholder(height: 150, label: 'ภาพถ่ายจริงของอุทยานหินเขางู'),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: forest, padding: const EdgeInsets.symmetric(vertical: 15)),
            onPressed: onExplore, icon: const Icon(Icons.explore), label: const Text('เริ่มต้นสำรวจ', style: TextStyle(fontWeight: FontWeight.bold)),
          )),
        ]),
      ),
      const SizedBox(height: 22),
      const SectionTitle('เลือกกิจกรรมของคุณ'),
      const SizedBox(height: 12),
      GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.55,
        children: [
          ActionTile(icon: Icons.menu_book, title: 'เรียนรู้เขางู', subtitle: 'ประวัติและจุดสำคัญ', onTap: onExplore),
          ActionTile(icon: Icons.threed_rotation, title: 'แผนที่ 360°', subtitle: 'สำรวจจุดต่าง ๆ', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const Map360Page(fullPage: true)))),
          ActionTile(icon: Icons.egg_alt, title: 'เกมฟักไข่งู', subtitle: 'ตอบคำถามสะสมพลัง', onTap: onGame),
          ActionTile(icon: Icons.quiz, title: 'แบบทดสอบ', subtitle: 'ท้าทายความรู้', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage()))),
        ],
      ),
      const SizedBox(height: 16),
      AppCard(child: Row(children: [
        const Text('💡', style: TextStyle(fontSize: 30)),
        const SizedBox(width: 12),
        const Expanded(child: Text('เกร็ดนักสำรวจ\nเขางูเป็นแหล่งเรียนรู้ทั้งด้านธรรมชาติ ธรณีวิทยา และโบราณคดี', style: TextStyle(height: 1.4, color: ink))),
      ])),
    ]),
  );
}

class ActionTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  const ActionTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(18), onTap: onTap,
    child: AppCard(padding: const EdgeInsets.all(13), child: Row(children: [
      Icon(icon, color: forest, size: 27), const SizedBox(width: 9),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: ink)),
        Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.black54)),
      ])),
    ])),
  );
}

class LandscapePlaceholder extends StatelessWidget {
  final double height;
  final String label;
  const LandscapePlaceholder({super.key, this.height = 170, this.label = 'พื้นที่สำหรับภาพถ่ายจริง'});
  @override
  Widget build(BuildContext context) => Container(
    height: height, width: double.infinity,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFB8D8E9), Color(0xFFE4EECF), Color(0xFF86B77C)]),
    ),
    child: Stack(children: [
      Positioned(left: 14, bottom: 10, child: Icon(Icons.landscape, size: height * .65, color: const Color(0xFF638D63))),
      Positioned(right: 20, bottom: 10, child: Icon(Icons.terrain, size: height * .78, color: const Color(0xFF718F68))),
      Align(alignment: Alignment.bottomCenter, child: Container(
        margin: const EdgeInsets.all(8), padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: Colors.white.withOpacity(.84), borderRadius: BorderRadius.circular(12)),
        child: Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: ink)),
      )),
    ]),
  );
}

class ExplorePage extends StatelessWidget {
  const ExplorePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('สำรวจเขางู')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const LandscapePlaceholder(height: 190, label: 'รอใส่ภาพถ่ายจริงที่ได้รับอนุญาต'),
      const SizedBox(height: 14),
      const Text('อุทยานหินเขางู จังหวัดราชบุรี', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: ink)),
      const SizedBox(height: 8),
      const Text('ตั้งอยู่ในตำบลเกาะพลับพลา อำเภอเมืองราชบุรี เป็นพื้นที่ที่มีความสำคัญทั้งด้านภูมิประเทศและแหล่งโบราณคดี', style: TextStyle(height: 1.55)),
      const SizedBox(height: 18),
      const SectionTitle('เรื่องน่ารู้'),
      const SizedBox(height: 10),
      InfoTile(icon: Icons.history_edu, title: 'จากพื้นที่ทำเหมืองสู่แหล่งท่องเที่ยว', body: 'ในอดีตพื้นที่เขางูเป็นแหล่งระเบิดและย่อยหิน ต่อมามีการพัฒนาเป็นสวนสาธารณะและแหล่งท่องเที่ยว', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PointDetailPage(title: 'จากพื้นที่ทำเหมืองสู่แหล่งท่องเที่ยว', body: 'พื้นที่เขางูเคยเป็นแหล่งระเบิดและย่อยหินปูน ต่อมามีการยกเลิกสัมปทานและพัฒนาเป็นสวนสาธารณะกับแหล่งท่องเที่ยวของจังหวัดราชบุรี')))),
      InfoTile(icon: Icons.account_balance, title: 'แหล่งโบราณคดี', body: 'บริเวณเทือกเขางูมีถ้ำสำคัญ ได้แก่ ถ้ำฤๅษี ถ้ำจีน ถ้ำจาม และถ้ำฝาโถ', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PointDetailPage(title: 'แหล่งโบราณคดี', body: 'บริเวณเทือกเขางูมีแหล่งโบราณคดีภายในถ้ำ 4 แห่ง ได้แก่ ถ้ำฤๅษี ถ้ำจีน ถ้ำจาม และถ้ำฝาโถ โดยเป็นหลักฐานที่เกี่ยวข้องกับพุทธศาสนา')))),
      InfoTile(icon: Icons.public, title: 'มรดกทางวัฒนธรรม', body: 'หลักฐานในถ้ำเกี่ยวข้องกับพุทธศาสนา และมีการกำหนดอายุศิลปกรรมบางส่วนไว้ในสมัยทวารวดี', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PointDetailPage(title: 'มรดกทางวัฒนธรรม', body: 'ข้อมูลจากหน่วยงานด้านโบราณคดีระบุว่าหลักฐานบางส่วนในถ้ำเขางูมีความเกี่ยวข้องกับศิลปกรรมสมัยทวารวดี และมีการใช้พื้นที่ต่อเนื่องในยุคหลัง')))),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage())), icon: const Icon(Icons.quiz), label: const Text('ทดสอบความรู้เรื่องเขางู')),
    ]),
  );
}

class InfoTile extends StatelessWidget {
  final IconData icon;
  final String title, body;
  final VoidCallback? onTap;
  const InfoTile({super.key, required this.icon, required this.title, required this.body, this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: InkWell(
      borderRadius: BorderRadius.circular(22), onTap: onTap,
      child: AppCard(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: forest, size: 27), const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: ink)),
          const SizedBox(height: 5), Text(body, style: const TextStyle(height: 1.45)),
        ])),
        if (onTap != null) const Icon(Icons.chevron_right, color: leaf),
      ])),
    ),
  );
}

class Map360Page extends StatelessWidget {
  final bool fullPage;
  const Map360Page({super.key, this.fullPage = false});
  @override
  Widget build(BuildContext context) {
    final content = Column(children: [
      Expanded(child: FlutterMap(
        options: const MapOptions(initialCenter: LatLng(13.5749, 99.7773), initialZoom: 14.5),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.example.khao_ngu_explorer',
          ),
          MarkerLayer(markers: [
            Marker(point: const LatLng(13.5749, 99.7773), width: 46, height: 46,
              child: const Icon(Icons.location_pin, color: forest, size: 42)),
            Marker(point: const LatLng(13.5743, 99.7729), width: 46, height: 46,
              child: const Icon(Icons.location_pin, color: Colors.orange, size: 42)),
          ]),
          const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap contributors')]),
        ],
      )),
      Container(
        color: cream, padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('แผนที่และจุดเรียนรู้', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: ink)),
          const SizedBox(height: 6),
          const Text('แสดงตำแหน่งอ้างอิงบริเวณเขางู จุดถ้ำและพิกัดต้องตรวจสอบภาคสนามก่อนเผยแพร่'),
          const SizedBox(height: 10),
          const LandscapePlaceholder(height: 105, label: 'ช่องสำหรับภาพพาโนรามา 360° จริง'),
          const SizedBox(height: 6),
          const Text('หมายเหตุ: หน้านี้มีแผนที่ออนไลน์แล้ว ส่วนการหมุนชม 360° ต้องเพิ่มไฟล์ภาพพาโนรามาที่ถ่ายจริง', style: TextStyle(fontSize: 11, color: Colors.black54)),
        ]),
      ),
    ]);
    return fullPage ? Scaffold(appBar: AppBar(title: const Text('แผนที่ 360°')), body: content)
      : Scaffold(appBar: AppBar(title: const Text('แผนที่ 360°')), body: content);
  }
}

class EggGamePage extends StatefulWidget {
  final int progress;
  final VoidCallback onTapEgg;
  const EggGamePage({super.key, required this.progress, required this.onTapEgg});
  @override
  State<EggGamePage> createState() => _EggGamePageState();
}

class _EggGamePageState extends State<EggGamePage> {
  @override
  Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
    const Text('เกมฟักไข่งู', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 8),
    AppCard(child: Column(children: [
      const Mascot(size: 88),
      const SizedBox(height: 8),
      const Text('ช่วยน้องงูฟักไข่กันเถอะ!', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: forest)),
      const Text('ตอบคำถามหรือแตะไข่เพื่อรับพลังงานสำรวจ', textAlign: TextAlign.center),
      const SizedBox(height: 18),
      GestureDetector(onTap: widget.onTapEgg, child: const Text('🥚', style: TextStyle(fontSize: 105))),
      Text('พลังการฟัก ${widget.progress.clamp(0, 5)}/5', style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(
        minHeight: 13, value: widget.progress.clamp(0, 5) / 5,
        backgroundColor: const Color(0xFFE7E9D9), color: forest)),
      const SizedBox(height: 12),
      FilledButton(onPressed: widget.onTapEgg, child: const Text('แตะเพื่อเพิ่มพลังฟักไข่')),
      if (widget.progress >= 5) const Text('🎉 ไข่ฟักแล้ว! ได้รับตัวละครใหม่', style: TextStyle(color: forest, fontWeight: FontWeight.bold)),
    ])),
    const SizedBox(height: 16),
    const InfoTile(icon: Icons.lightbulb_outline, title: 'เกร็ดความรู้', body: 'เกมนี้เป็นกิจกรรมทบทวนความรู้เกี่ยวกับเขางู สามารถเพิ่มคำถามและภารกิจจากข้อมูลที่ตรวจสอบแล้วได้'),
  ]));
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override
  State<QuizPage> createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  int? selected;
  bool submitted = false;
  final answers = ['กาญจนบุรี', 'ราชบุรี', 'เพชรบุรี'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('คำถามประวัติศาสตร์')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const LinearProgressIndicator(value: 1 / 5, color: forest, backgroundColor: Color(0xFFE2E8D9)),
        const SizedBox(height: 18),
        const AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('คำถามที่ 1', style: TextStyle(color: forest, fontWeight: FontWeight.w800)),
          SizedBox(height: 8),
          Text('อุทยานหินเขางูตั้งอยู่ในจังหวัดใด?', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: ink)),
        ])),
        const SizedBox(height: 14),
        ...List.generate(answers.length, (i) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15), side: BorderSide(color: selected == i ? forest : const Color(0xFFE4E8DA), width: selected == i ? 2 : 1)),
            tileColor: cream, leading: Icon(selected == i ? Icons.radio_button_checked : Icons.radio_button_off, color: forest),
            title: Text(answers[i]), onTap: submitted ? null : () => setState(() => selected = i),
          ),
        )),
        FilledButton(onPressed: selected == null || submitted ? null : () => setState(() => submitted = true), child: const Text('ตรวจคำตอบ')),
        if (submitted) AppCard(child: Text(selected == 1 ? 'ถูกต้อง! เขางูอยู่ในจังหวัดราชบุรี 🎉' : 'ยังไม่ถูกนะ คำตอบคือจังหวัดราชบุรี', style: const TextStyle(fontWeight: FontWeight.bold, color: forest))),
      ]),
    );
  }
}

class CollectionPage extends StatelessWidget {
  final Set<int> unlocked;
  const CollectionPage({super.key, required this.unlocked});
  @override
  Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
    const Text('คลังสะสมงู', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 8),
    AppCard(child: Column(children: [
      const Text('สะสมความรู้ รับตัวละครพิเศษ!', style: TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      Text('${unlocked.length}/5 ตัวละคร', style: const TextStyle(color: forest, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      const LinearProgressIndicator(value: .2, color: forest, backgroundColor: Color(0xFFE5E9DC)),
    ])),
    const SizedBox(height: 14),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.1, crossAxisSpacing: 12, mainAxisSpacing: 12,
      children: List.generate(6, (i) => AppCard(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(unlocked.contains(i) ? ['🐍','🐉','🌱','🍃','⭐','🌼'][i] : '🔒', style: const TextStyle(fontSize: 43)),
        const SizedBox(height: 8),
        Text(unlocked.contains(i) ? ['น้องใบชา','งูน้อยนักสำรวจ','ผู้พิทักษ์ป่า','นักเดินทาง','นักค้นพบ','เพื่อนรักธรรมชาติ'][i] : 'ตัวละครที่ ${i+1}', style: const TextStyle(fontWeight: FontWeight.w800, color: ink)),
        Text(unlocked.contains(i) ? 'ปลดล็อกแล้ว' : 'ทำภารกิจเพื่อปลดล็อก', style: const TextStyle(fontSize: 10, color: Colors.black54)),
      ]))),
    ),
  ]));
}

class ProfilePage extends StatelessWidget {
  final int score, progress;
  const ProfilePage({super.key, required this.score, required this.progress});
  @override
  Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
    const Text('โปรไฟล์นักสำรวจ', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 14),
    AppCard(child: Row(children: [
      const Mascot(size: 82), const SizedBox(width: 14),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('นักสำรวจเขางู', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: ink)),
        Text('ระดับเริ่มต้น · Explorer Lv.1'),
      ])),
    ])),
    const SizedBox(height: 14),
    Row(children: [
      Expanded(child: AppCard(child: Column(children: [const Icon(Icons.star, color: gold, size: 30), const Text('คะแนนสะสม'), Text('$score', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900))]))),
      const SizedBox(width: 10),
      Expanded(child: AppCard(child: Column(children: [const Icon(Icons.egg_alt, color: forest, size: 30), const Text('ความคืบหน้าไข่'), Text('$progress/5', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900))]))),
    ]),
    const SizedBox(height: 14),
    const SectionTitle('ความสำเร็จของฉัน'),
    const SizedBox(height: 10),
    const AppCard(child: Wrap(spacing: 18, runSpacing: 18, children: [
      _Badge('🌿','เริ่มสำรวจ'), _Badge('🗺️','นักเดินทาง'), _Badge('📚','ใฝ่รู้'), _Badge('🥚','ผู้ดูแลไข่'),
    ])),
  ]));
}

class _Badge extends StatelessWidget {
  final String emoji, label;
  const _Badge(this.emoji, this.label);
  @override
  Widget build(BuildContext context) => SizedBox(width: 105, child: Column(children: [
    Text(emoji, style: const TextStyle(fontSize: 30)),
    Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
  ]));
}


class PointDetailPage extends StatelessWidget {
  final String title, body;
  const PointDetailPage({super.key, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('รายละเอียดจุดเรียนรู้')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const LandscapePlaceholder(height: 210, label: 'ใส่ภาพถ่ายจริงของจุดเรียนรู้'),
      const SizedBox(height: 16),
      Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: ink)),
      const SizedBox(height: 10),
      Text(body, style: const TextStyle(fontSize: 16, height: 1.65)),
      const SizedBox(height: 16),
      const AppCard(child: Text('ข้อมูลนี้เป็นเนื้อหาเบื้องต้น ควรตรวจทานกับหน่วยงานผู้ดูแลและแหล่งข้อมูลทางการก่อนเผยแพร่', style: TextStyle(fontSize: 12, color: Colors.black54))),
    ]),
  );
}
